# Copyright 2019 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""A demo to classify Raspberry Pi camera stream."""

import argparse
import io
import time

import numpy as np
import picamera

import board
import neopixel
pixels = neopixel.NeoPixel(board.D18, 144, auto_write=False, brightness=0.3)

def light_it_up(from_x, to_x):
    led_from = int(144*from_x)
    led_to = int(144*to_x)
    pixels.fill((0, 0, 0))
    for i in range(led_from, led_to):
        pixels[143-i] = (0, 10, 0)
    pixels.show()
    
    

from edgetpu.detection.engine import DetectionEngine

from annotator.annotator import Annotator

DISPLAY = True

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
      '--model', help='File path of Tflite model.', required=True)
    parser.add_argument(
      '--label', help='File path of label file.', required=False)
    args = parser.parse_args()
    
    if args.label:
        with open(args.label, 'r', encoding="utf-8") as f:
            pairs = (l.strip().split(maxsplit=1) for l in f.readlines())
            labels = dict((int(k), v) for k, v in pairs)

    engine = DetectionEngine(args.model)
    


    with picamera.PiCamera() as camera:
        camera.resolution = (640, 480)
        camera.framerate = 30
        _, width, height, channels = engine.get_input_tensor_shape()
        if DISPLAY:
            camera.start_preview()
            annotator = Annotator(camera, dimensions=(640, 480))
       
        try:
            stream = io.BytesIO()
            for foo in camera.capture_continuous(stream,
                                                 format='rgb',
                                                 use_video_port=True,
                                                 resize=(width, height)):
                stream.truncate()
                stream.seek(0)
                input = np.frombuffer(stream.getvalue(), dtype=np.uint8)
                start_ms = time.time()
                results = engine.DetectWithInputTensor(input, top_k=1)
                elapsed_ms = time.time() - start_ms
                
                    
                if DISPLAY:
                    camera.annotate_text = "%.2fms" % (elapsed_ms*1000.0)
                if results:
                    
                    box = results[0].bounding_box
                    
                    if DISPLAY:
                        annotator.clear()
                        annotator.bounding_box((box[0][0]*640,
                                            box[0][1]*480,
                                            box[1][0]*640,
                                            box[1][1]*480))
                        annotator.update()
                    
                    light_it_up(box[0][0], box[1][0])
                else:
                    light_it_up(0, 0)
                #if results:

                 #   c
        finally:
            if DISPLAY:
                camera.stop_preview()
            pass

if __name__ == '__main__':
    main()
